import requests
import json
data = {'nom':'Nestor Alberto', 'usu':'epapgu', 'ema':'ntorres@uninorte.edu.co', 'cla':'Lppb09'}
dat = requests.post(f'http://localhost:8080/register/', params=data)
dat = requests.get(f'http://localhost:8080/login/John1/prueba1/')
if dat.status_code==200:
    dat = json.loads(dat.content)
    print(dat)
