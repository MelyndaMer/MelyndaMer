from flask_wtf import FlaskForm
from wtforms import TextField, SubmitField, PasswordField, TextAreaField,StringField, DateField, BooleanField, IntegerField,Form,validators
from wtforms.fields.html5 import EmailField
from wtforms.validators import EqualTo, InputRequired,DataRequired, Email, Length

class Login(FlaskForm):
    usu = TextField('Usuario *', validators = [InputRequired(message='Indique el usuario')])
    cla = PasswordField('Clave *', validators = [InputRequired(message='Indique la clave')])
    btn = SubmitField('Login')

class Registro(FlaskForm):
    nom = TextField('Nombre *', validators = [InputRequired(message='Indique el nombre')])
    usu = TextField('Usuario *', validators = [InputRequired(message='Indique el usuario')])
    ema = EmailField('Email *', validators = [InputRequired(message='Indique el email')])
    cla = PasswordField('Clave *', validators = [InputRequired(message='Indique la clave')])
    ver = PasswordField('Verificación *', validators = [InputRequired(message='Indique la verificación'), EqualTo(cla,message='Clave y la verificación no coinciden')])
    btn = SubmitField('Registrar')

class Send(FlaskForm):
    par = TextField('Para *', validators = [InputRequired(message='Indique el destinatario')])
    par = TextField('Asunto *', validators = [InputRequired(message='Indique el asunto')])
    men = TextAreaField('Mensaje *', validators = [InputRequired(message='Indique el mensaje')])
    btn = SubmitField('Enviar')

class FormularioRegistro(FlaskForm):
    name = StringField('Nombre completo', validators=[DataRequired(), Length(max=64)])
    tel = StringField('Teléfono de contacto', validators=[DataRequired()])
    password = PasswordField('Contraseña', validators=[DataRequired()])
    confirmar_password = PasswordField('Confirmar contraseña', validators=[DataRequired()])  
    date = DateField('Fecha de nacimiento', validators=[DataRequired()])
    email = StringField('Correo', validators=[DataRequired(), Email()])
    submit = SubmitField('Registrar')



class FormularioLogin(FlaskForm):
    email = StringField('Correo', validators=[DataRequired()])
    password = PasswordField('Cotraseña', validators=[DataRequired()])
    remember_me = BooleanField('Recuérdame')
    submit = SubmitField('Login')

class FormularioHabitacion():
    idh = StringField(' Id Habitacion', validators=[DataRequired()])
    ubicacion = StringField('Ubicacion', validators=[DataRequired()])
    precio = IntegerField('Precio', validators=[DataRequired()])    
    submit = SubmitField('Agregar')

class FormularioComentario():
    calificacion = IntegerField('Calificación', validators=[DataRequired()])
    idh = StringField(' Id Habitacion', validators=[DataRequired()])
    desc = TextAreaField(' Id Habitacion', validators=[DataRequired()])

    submit = SubmitField('Agregar')

