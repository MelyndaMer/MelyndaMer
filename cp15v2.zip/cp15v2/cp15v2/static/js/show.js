function toggleFormUser() {

    var notForm = document.getElementById('notFormUser');
    var myForm = document.getElementById('formUser');



    var displaySetting = notForm.style.display;

    if (displaySetting == 'block') {

        notForm.style.display = 'none';

        myForm.style.display = 'block'

    } else {

        notForm.style.display = 'block';

        myForm.style.display = 'none';


    }

}

function toggleFormHabitacion() {

    var notForm = document.getElementById('notFormHabitacion');
    var myForm = document.getElementById('formHabitacion');



    var displaySetting = notForm.style.display;

    if (displaySetting == 'block') {

        notForm.style.display = 'none';

        myForm.style.display = 'block'

    } else {

        notForm.style.display = 'block';

        myForm.style.display = 'none';


    }

}