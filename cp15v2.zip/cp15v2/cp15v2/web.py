from flask import Flask, render_template, redirect, session, flash, request, send_file
from flask.helpers import url_for
from forms import Login, Registro, Send
from markupsafe import escape
import os
from utils import login_valido, pass_valido, email_valido
from db import seleccion, accion
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

app.secret_key = os.urandom(24)
admin = True

@app.errorhandler(404)
def e404(e):
    return render_template('404.html'), 404



@app.route('/',methods=['GET', 'POST'])
def home():
    """ V6, se añade autenticación de cliente HTTPS y Gestión de estados """
    
    return render_template('home.html',admin=admin, session=session)

@app.route('/login')
@app.route('/home/')
@app.route('/index/')
def inicio():
    """ V6, se añade autenticación de cliente HTTPS y Gestión de estados """
    frm=Login()
    return render_template('login.html', prueba=frm, titulo='Iniciar Sesión')



@app.route('/login', methods=['POST'])
def login():
    """ V6, se añade autenticación de cliente HTTPS y Gestión de estados """
    frm=Login()
    # Será un código con mitigación de riesgo
    usu = escape(frm.usu.data.strip())
    pwd = escape(frm.cla.data.strip())
    # Preparar la consulta 
    sql = f"SELECT id, nombre, correo, clave, rol FROM usuario WHERE usuario='{usu}'"
    # Ejecutar la consulta
    res = seleccion(sql)
    # Valido los resultados
    if len(res)>0:
        cbd = res[0][3] 
        # Comprobar la clave
        if check_password_hash(cbd,pwd):
            session.clear()
            session['id'] = res[0][0]
            session['nom'] = res[0][1]
            session['usr'] = usu
            session['cla'] = pwd
            session['ema'] = res[0][2]
            session['rol'] = res[0][4]
            print(session['rol'])
            return redirect('/')

        else:
            flash('ERROR: Usuario o clave no validos')
            return render_template('login.html', prueba=frm, titulo='Iniciar Sesión')
    else:
        flash('ERROR: Usuario o clave no validos')
        return render_template('login.html', prueba=frm, titulo='Iniciar Sesión')
    

@app.route('/reservar')
def reservar():

    user= session['id']
    capac=request.form["select-1"]
    ingreso=request.form["checkin"]
    salida=request.form["checkout"]

    sql = "INSERT INTO usuario(nombre, ingreso, salida, capacidad) VALUES (?, ?, ?, ?)"
    # Ejecutar la consulta
    res = accion(sql,(user, ingreso, salida, capac))
    if res!=0:
        flash('INFO: Datos han sido exitosamente grabados')
    else:
        flash('ERROR: Por favor reintente')

    return redirect("/")


@app.route('/message/')
def messages():
    """ V6, se añade autenticación de cliente HTTPS y Gestión de estados """
    usu = session['id']
    # Preparar la consulta 
    sql = f"SELECT de, para, asunto, mensaje FROM mensajes WHERE para={usu}"
    # Ejecutar la consulta
    res = seleccion(sql)
    # Valido los resultados
    if len(res)>0:
        tit = f"Se muestran los mensajes para {session['nom']}"
    else:
        tit = f"No hay mensajes para {session['nom']}"
    return render_template('mensajes.html', titulo=tit, messages=res)

@app.route('/logout/', methods=['GET', 'POST'])
def logout():
    """ V6, se añade autenticación de cliente HTTPS y Gestión de estados """
    session.clear()
    return redirect('/')

@app.route('/register/', methods=['GET', 'POST'])
def register():
    """ V6, se añade autenticación de cliente HTTPS y Gestión de estados """
    frm = Registro()
    if request.method == 'GET':
        return render_template('registro.html', prueba=frm, titulo='Registro de datos')
    else:
        # Recuperar los datos del formulario
        nom = escape(request.form['nom'])
        usu = escape(request.form['usu'])
        ema = escape(request.form['ema'])
        cla = escape(request.form['cla'])
        ver = escape(request.form['ver'])
        # Validar los datos
        swerror = False
        if nom==None or len(nom)==0:
            flash('ERROR: Debe suministrar un nombre de usuario')
            swerror = True
        if usu==None or len(usu)==0 or not login_valido(usu):
            flash('ERROR: Debe suministrar un usuario válido ')
            swerror = True
        if ema==None or len(ema)==0 or not email_valido(ema):
            flash('ERROR: Debe suministrar un email válido')
            swerror = True
        if cla==None or len(cla)==0 or not pass_valido(cla):
            flash('ERROR: Debe suministrar una clave válida')
            swerror = True
        if ver==None or len(ver)==0 or not pass_valido(ver):
            flash('ERROR: Debe suministrar una verificación de clave válida')
            swerror = True
        if cla!=ver:
            flash('ERROR: La clave y la verificación no coinciden')
            swerror = True
        if not swerror:
            # Preparar la consulta
            sql = "INSERT INTO usuario(nombre, usuario, correo, clave) VALUES (?, ?, ?, ?)"
            # Ejecutar la consulta
            pwd = generate_password_hash(cla)
            res = accion(sql,(nom, usu, ema, pwd))
            # Procesar la respuesta
            if res!=0:
                flash('INFO: Datos han sido exitosamente grabados')
            else:
                flash('ERROR: Por favor reintente')
        return render_template('registro.html', prueba=frm, titulo='Registro de datos')

@app.route('/send/', methods=['GET', 'POST'])
def send():
    """ V6, se añade autenticación de cliente HTTPS y Gestión de estados """
    frm = Send()
    if request.method == 'GET':
        return render_template('send.html', prueba=frm, titulo='Envío de mensajes')
    else:
        # Recuperar los datos del formulario
        par = escape(request.form['par'])
        asu = escape(request.form['asu'])
        men = escape(request.form['men'])
        # Validar los datos
        swerror = False
        if par==None or len(par)==0:
            flash('ERROR: Debe suministrar el destinatario')
            swerror = True
        if asu==None or len(asu)==0:
            flash('ERROR: Debe suministrar el asunto')
            swerror = True
        if men==None or len(men)==0:
            flash('ERROR: Debe suministrar el mensaje')
            swerror = True
        if not swerror:
            # Preparar la consulta
            sql = "INSERT INTO mensajes(de, para, asunto, mensaje) VALUES (?, ?, ?, ?)"
            # Ejecutar la consulta
            res = accion(sql,(session['id'], par, asu, men))
            # Procesar la respuesta
            if res!=0:
                flash('INFO: Datos han sido exitosamente grabados')
            else:
                flash('ERROR: Por favor reintente')
        return render_template('send.html', prueba=frm, titulo='Envío de mensajes')

@app.route('/dowpdf/')
def dowpdf():
    """ Descargar un archivo de la página """
    return send_file("resources/doc.pdf", as_attachment=True)

@app.route('/dowimg/<path:fna>')
def dowimg(fna=None):
    """ Descargar un archivo de la página """
    if fna!=None:
        return send_file(fna, as_attachment=True)
    else:
        return redirect('/')
    
@app.route('/base')
def base():
    """ Descargar un archivo de la página """
    return render_template("base.html")

    



@app.route("/inicio/busqueda/reserva", methods=["GET", "POST"])
def busqueda1():

    user=session["id"]
    capac=request.form["select"]
    ingreso=request.form["checkin"]
    salida=request.form["checkout"]
    hab=None
    imagenhab=""
    
    if request.form["Habitaciónsubmit"]=="Reservar 1":
        hab="Habitación Standard"
        imagenhab="/static/images/australian-modern-bedroom-interior-nature-window_31965-3690.jpg"
    elif request.form["Habitaciónsubmit"]=="Reservar 2":
        hab="Habitación doble"
        imagenhab="/static/images/modern-studio-apartment-design-with-bedroom-living-space_1262-12375.jpg"
    elif request.form["Habitaciónsubmit"]=="Reservar 3":
        hab="Suite"
        imagenhab="/static/images/luxury-bedroom-hotel_1150-10836.jpg"

    sql = "INSERT INTO Reservas (name, ingreso, salida, capacidad) VALUES (?, ?, ?, ?)"
    # Ejecutar la consulta
    res = accion(sql,(user, ingreso, salida, capac))
    if res!=0:
        flash('INFO: Datos han sido exitosamente grabados')
    else:
        flash('ERROR: Por favor reintente')


    return render_template('habitacion.html', admin=admin,session=session, hab=hab, ingreso=ingreso, salida=salida,capac=capac,imagenhab=imagenhab)
   




@app.route("/inicio/busqueda", methods=["GET", "POST"])
def busqueda():

    Ruta=""

    return render_template('reservar.html', admin=admin, session=session,ruta=Ruta)



if __name__ == '__main__':
    app.run(debug=True)


